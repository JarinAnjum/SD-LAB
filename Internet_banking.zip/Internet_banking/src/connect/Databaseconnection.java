
        /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.util.*;


/**
 *
 * @author shaha
 */
public class Databaseconnection {
 public static Connection connecrDB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      private Connection con;
      private static Databaseconnection dbc;
    private Databaseconnection(){
     try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("loaded");
            
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinebanking","root","");
              System.out.println("connect");
          
            
        }
        catch(Exception ex){
            System.out.println("Error: "+ex);
        }
    } 
    public static Databaseconnection getDatabaseconnection()
    {
        if(dbc==null)
        {
            dbc = new Databaseconnection();
        }
        return dbc;
    }
     public  Connection getConnection()
     {
         return con;
     }
      public static void main(String args[]) {
 Databaseconnection dbc =new Databaseconnection();
          
}

    public PreparedStatement preparedStatement(String query) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

 

    
